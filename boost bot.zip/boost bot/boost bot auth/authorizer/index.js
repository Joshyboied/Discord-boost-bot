const fs = require('fs');
const axios = require('axios');
const { DateTime } = require('luxon');

const { CLIENTID, CLIENTSECRET, REDIRECTURI } = require("./config.json");
const FILEPATH = "auth.txt";
const RETRY_DELAY = 2000; 

async function TokenAuth(Token, AccountNo) {
    const Ct = DateTime.now().toFormat('HH:mm:ss');
    try {
        const authConfig = {
            headers: { 'Authorization': Token }
        };

        const authResponse = await axios.post(
            `https://discord.com/api/v9/oauth2/authorize?client_id=${CLIENTID}&response_type=code&redirect_uri=${encodeURIComponent(REDIRECTURI)}&scope=identify%20guilds%20guilds.join%20connections%20guilds.members.read%20role_connections.write`, 
            { permissions: "0", authorize: true },
            authConfig
        );

        if (authResponse.status !== 200) {
            console.log(`[-] | ${Ct} | INVALID | [${authResponse.statusText}]`);
            return;
        }

        const code = new URLSearchParams(authResponse.data.location.split('?')[1]).get('code');

        const tokenResponse = await axios.post('https://discord.com/api/v9/oauth2/token',
            new URLSearchParams({
                'client_id': CLIENTID,
                'client_secret': CLIENTSECRET,
                'grant_type': 'authorization_code',
                'code': code,
                'redirect_uri': REDIRECTURI
            }),
            {
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                ...authConfig
            }
        );

        const { access_token, refresh_token } = tokenResponse.data;

        const userResponse = await axios.get("https://discordapp.com/api/v6/users/@me", {
            headers: {
                'Authorization': `Bearer ${access_token}`
            }
        });

        const memberid = userResponse.data.id;
        const authData = `${access_token}:${refresh_token}:${memberid}:${Token}`;
        fs.appendFileSync(FILEPATH, authData + '\n');

        console.log(`\x1b[32m[+] | ${Ct} | SUCCESS | [${access_token}] | UserID: ${memberid}\x1b[0m`);
    } catch (error) {
        if (error.response && error.response.status === 429) {
            console.log(`[-] | ${Ct} | RATE LIMIT | Waiting for 2 seconds...`);
            await new Promise(resolve => setTimeout(resolve, RETRY_DELAY));
            await TokenAuth(Token, AccountNo); 
        } else {
            console.error('Error:', error.response ? error.response.data : error.message);
        }
    }
}

async function TOKENTOAUTH() {
    const lines = fs.readFileSync('Token.txt', 'utf-8').split('\n').filter(Boolean);

    for (const [index, line] of lines.entries()) {
        await TokenAuth(line.trim(), index + 1);
    }
    
    console.log("Saving data to auth.txt");
}

TOKENTOAUTH();
