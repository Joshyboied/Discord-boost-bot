const { Client, GatewayIntentBits, PermissionsBitField, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const fs = require('fs');
const axios = require('axios');
const config = require('./config.json');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ]
});

const prefix = config.prefix;
let joiningGuilds = {};

client.once('ready', () => {
  console.log('Bot is ready!');
});


client.on('messageCreate', async message => {
  if (!message.content.startsWith(prefix) || message.author.bot) return;

  const args = message.content.slice(prefix.length).trim().split(/ +/);
  const command = args.shift().toLowerCase();


if(command === 'help'){
  message.reply('.send <guild id> <number of id>\n.boost <invoice id>')
}

   if (command === 'send') {
    if (message.author.id !== config.ownerId) {
      return message.reply('You do not have permission to use this command.');
    }

    const guildId = args[0];
    const numberOfAuths = parseInt(args[1]);

    if (!guildId || isNaN(numberOfAuths) || numberOfAuths <= 0) {
      return message.reply('Please provide a valid guild ID and number of auths.');
    }

    const userId = message.author.id;

    let authsFile = 'auth.txt';
    const auths = fs.readFileSync(authsFile, 'utf-8').trim().split('\n');

    if (auths.length < numberOfAuths) {
      return message.reply('Not enough available access tokens.');
    }

    const tokensToUse = auths.slice(0, numberOfAuths);

    joiningGuilds[guildId] = true;

    const logsChannel = await client.channels.fetch(config.logsChannelId);
    const embed = new EmbedBuilder()
      .setTitle('Joining Members')
      .addFields(
        { name: 'User', value: `<@${userId}>`, inline: true },
        { name: 'Time', value: new Date().toLocaleString(), inline: true },
        { name: 'Number of Members', value: numberOfAuths.toString(), inline: true },
        { name: 'Guild', value: `${message.guild.name} (${guildId})`, inline: true }
      );

    const stopButton = new ButtonBuilder()
      .setCustomId(`stop_joining_${guildId}`)
      .setLabel('Stop Joining')
      .setStyle(ButtonStyle.Danger);

    const row = new ActionRowBuilder().addComponents(stopButton);

    const embedMessage = await logsChannel.send({ embeds: [embed], components: [row] });

    let successfulBoosts = 0;
    let failedBoosts = 0;

    for (let i = 0; i < tokensToUse.length; i++) {
      if (!joiningGuilds[guildId]) break;

      const [accessToken, refreshToken, userId, token] = tokensToUse[i].split(':');
      await updateGuildMemberAccessToken(userId, accessToken, guildId, token);

      const boostResult = await performBoosting(token);

      if (boostResult.successful > 0) {
        successfulBoosts += boostResult.successful;
      } else {
        failedBoosts += 1;
        fs.appendFileSync('invalid.txt', `${tokensToUse[i]}\n`);
      }

      if ((i + 1) % 5 === 0) {
        await new Promise(resolve => setTimeout(resolve, 5000));
      }
    }

    if (joiningGuilds[guildId]) {
      delete joiningGuilds[guildId];
      
      const updateEmbed = new EmbedBuilder()
        .setTitle('Boosting Status')
        .addFields(
          { name: 'Successful Joins', value: tokensToUse.length.toString(), inline: true },
          { name: 'Successful Boosts', value: successfulBoosts.toString(), inline: true },
          { name: 'Failed Boosts', value: failedBoosts.toString(), inline: true }
        );
      await message.author.send({ embeds: [updateEmbed] });
      await embedMessage.edit({ embeds: [updateEmbed] });

      tokensToUse.forEach(token => {
        if (token.split(':').length === 3) {
          fs.appendFileSync('done.txt', `${token}\n`);
        }
      });
    }

    const remainingAuths = auths.filter(auth => !tokensToUse.includes(auth));
    fs.writeFileSync(authsFile, remainingAuths.join('\n'));

  }
});



client.on('messageCreate', async message => {
  if (!message.content.startsWith(prefix) || message.author.bot) return;

  const args = message.content.slice(prefix.length).trim().split(/ +/);
  const command = args.shift().toLowerCase();

  if (command === 'boost') {
    const uniqid = args[0];
    const guildId = message.guild.id;
    const userId = message.author.id;

    if (!uniqid) {
      return message.reply('Please provide a unique ID.');
    }

    const options = {
      headers: {
        Authorization: `Bearer ${config.apiKey}`
      }
    };

    try {
      const response = await axios.get(`https://dev.sellix.io/v1/orders/${uniqid}`, options);
      const order = response.data.data.order;
      if (!order) {
        return message.reply('Invalid unique ID.');
      }

      const productId = order.product_id;
      const cryptoReceived = order.crypto_received;
      if (cryptoReceived === 0) {
        return message.reply('Invoice is not paid.');
      }

      let authsFile = '';
      if (productId === config.boostProductId) {
        authsFile = 'auth.txt';
      } else {
        return message.reply('Invalid product ID.');
      }

      const quantity = order.quantity;
      const keys = JSON.parse(fs.readFileSync('keys.json', 'utf-8')) || [];
      const auths = fs.readFileSync(authsFile, 'utf-8').trim().split('\n');

      if (keys.find(k => k.key === uniqid)) {
        return message.reply('This unique ID has already been used.');
      }

      if (auths.length < quantity) {
        return message.reply('Not enough available access tokens.');
      }

      const tokensToUse = auths.slice(0, quantity);

      joiningGuilds[guildId] = true;

      const logsChannel = await client.channels.fetch(config.logsChannelId);
      const embed = new EmbedBuilder()
        .setTitle('Joining Members')
        .addFields(
          { name: 'User', value: `<@${userId}>`, inline: true },
          { name: 'Time', value: new Date().toLocaleString(), inline: true },
          { name: 'Invoice ID', value: uniqid, inline: true },
          { name: 'Number of Members', value: quantity.toString(), inline: true },
          { name: 'Guild', value: `${message.guild.name} (${guildId})`, inline: true }
        );

      const stopButton = new ButtonBuilder()
        .setCustomId(`stop_joining_${guildId}`)
        .setLabel('Stop Joining')
        .setStyle(ButtonStyle.Danger);

      const row = new ActionRowBuilder().addComponents(stopButton);

      const embedMessage = await logsChannel.send({ embeds: [embed], components: [row] });

      let successfulBoosts = 0;
      let failedBoosts = 0;

      for (let i = 0; i < tokensToUse.length; i++) {
        if (!joiningGuilds[guildId]) break;

        const [accessToken, refreshToken, userId, token] = tokensToUse[i].split(':');
        await updateGuildMemberAccessToken(userId, accessToken, guildId, token);

        const boostResult = await performBoosting(token);

        if (boostResult.successful > 0) {
          successfulBoosts += boostResult.successful;
        } else {
          failedBoosts += 1;
          fs.appendFileSync('invalid.txt', `${tokensToUse[i]}\n`);
        }

        if ((i + 1) % 5 === 0) {
          await new Promise(resolve => setTimeout(resolve, 5000));
        }
      }

      if (joiningGuilds[guildId]) {
        delete joiningGuilds[guildId];
       
        const updateEmbed = new EmbedBuilder()
          .setTitle('Boosting Status')
          .addFields(
            { name: 'Successful Joins', value: tokensToUse.length.toString(), inline: true },
            { name: 'Successful Boosts', value: successfulBoosts.toString(), inline: true },
            { name: 'Failed Boosts', value: failedBoosts.toString(), inline: true }
          );
          await message.author.send({ embeds: [updateEmbed] });
        await embedMessage.edit({ embeds: [updateEmbed] });

        tokensToUse.forEach(token => {
          if (token.split(':').length === 3) {
            fs.appendFileSync('done.txt', `${token}\n`);
          }
        });
      }

      keys.push({ key: uniqid, status: true });
      fs.writeFileSync('keys.json', JSON.stringify(keys, null, 2));

      const remainingAuths = auths.filter(auth => !tokensToUse.includes(auth));
      fs.writeFileSync(authsFile, remainingAuths.join('\n'));

    } catch (err) {
      console.error(err);
      message.reply('Invalid code');
    }
  }
});

client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;

  const [action, guildId] = interaction.customId.split('_');

  if (action === 'stop' && joiningGuilds[guildId]) {
    if (interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
      delete joiningGuilds[guildId];
      await interaction.reply({ content: 'Stopped joining members for this guild.', ephemeral: true });
    } else {
      await interaction.reply({ content: 'You do not have permission to use this button.', ephemeral: true });
    }
  } else {
    await interaction.reply({ content: 'Members joining is already done or invalid action.', ephemeral: true });
  }
});

client.login(config.botToken);

async function updateGuildMemberAccessToken(userId, accessToken, guildId, token) {
  const guildEndpoint = `https://discord.com/api/v9/guilds/${guildId}/members/${userId}`;

  const options = {
    headers: {
      Authorization: `Bot ${config.botToken}`
    }
  };

  try {
    await axios.put(guildEndpoint, {
      access_token: accessToken
    }, options);
    console.log(`Successfully updated guild member access token for user ${userId}.`);
  } catch (error) {
    console.error(`Failed to update guild member access token for user ${userId}:`, error.response ? error.response.statusText : error.message);
  }
}

async function performBoosting(accessToken) {
  const auths = fs.readFileSync('auth.txt', 'utf-8').trim().split('\n');
  let successfulBoosts = 0;
  let boostIds = await getBoostIds(accessToken);

  if (boostIds.length === 0) {
    console.log(`${accessToken} has no boost`);
    fs.appendFileSync('invalid.txt', `${accessToken}\n`);
    return { successful: 0 };
  }

  for (const boostId of boostIds) {
    const boostResult = await sendBoost(boostId, accessToken);
    if (boostResult) {
      successfulBoosts++;
    }
  }

  const remainingAuths = auths.filter(auth => !auth.startsWith(accessToken));
  fs.writeFileSync('auth.txt', remainingAuths.join('\n'));

  fs.appendFileSync('done.txt', `${accessToken}\n`);

  return { successful: successfulBoosts };
}

async function getBoostIds(authToken) {
  try {
    const response = await axios.get('https://discord.com/api/v9/users/@me/guilds/premium/subscription-slots', {
      headers: { 'Authorization': `${authToken}` }
    });
    console.log(authToken)
        return response.data.map(boost => boost.id);
  } catch (error) {
    console.error('Error fetching boost IDs:', error.response ? error.response.data : error.message);
    return [];
  }
}

async function sendBoost(boostId, authToken) {
  const data = {
    user_premium_guild_subscription_slot_ids: [boostId]
  };

  try {
    const response = await axios.put(`https://discord.com/api/v9/guilds/${config.guildId}/premium/subscriptions`, data, {
      headers: {
        'Authorization': `${authToken}`,
        'Content-Type': 'application/json'
      }
    });
    console.log(`Boosted with Boost ID ${boostId}:`, response.data);
    return true;
  } catch (error) {
    console.error(`Error applying Boost ID ${boostId}:`, error.response ? error.response.data : error.message);
    return false;
  }
}
